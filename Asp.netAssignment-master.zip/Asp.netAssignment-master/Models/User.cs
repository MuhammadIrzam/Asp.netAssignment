﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myproject.Models
{
    public class User
    {
        public static String username { get; set; }
        public static String password { get; set; }

    }
}
