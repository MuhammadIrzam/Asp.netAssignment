﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myproject.Models
{
    public class Join
    {
        public static String username { get; set; }
        public static String password { get; set; }
    }
    
}
