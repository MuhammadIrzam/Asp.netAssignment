﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myproject.Models
{
    public class Assignment
    {
        public static String name { get; set; }
        public static String id { get; set; }
    }
}
